﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KursovaV2.Interface
{
    internal interface IShapes
    {
       abstract double CalculateArea();
       abstract void Draw(Graphics g);     
    }
}
