﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KursovaV2.Forms
{
    internal class Circle : Shapes
    {
        //Намиране на площа
        public override double CalculateArea()
        {
            return Math.PI * Width * Height;
        }

        // Изресуване на фигурите
        public override void Draw(Graphics g)
        {
            Pen h = new Pen(Color.Pink, 2);

            g.DrawEllipse(h, Position.X, Position.Y, Width, Height);
        }
    }
}
