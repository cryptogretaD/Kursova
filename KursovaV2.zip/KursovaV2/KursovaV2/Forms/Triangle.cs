﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KursovaV2.Forms
{
    public class Triangle :Shapes
    {
        // За площа
        public Triangle(double @base)
        {
            Base = @base;
        }

        public override double CalculateArea()
        {
            return 0.5 * Base * Height;
        }

        //Изрисуване на Фигури

        //public override void Draw(Graphics g)
        //{
        //Pen h = new Pen(Color.Pink,2);

        //g.DrawLine(h, 60, 30, 90, 90);
        //g.DrawLine(h, 60, 30, 30, 90);
        //g.DrawLine(h, 30, 90, 90, 90);
        // }

        public override void Draw(Graphics g)
        {
            throw new NotImplementedException();
        }
    }
}
