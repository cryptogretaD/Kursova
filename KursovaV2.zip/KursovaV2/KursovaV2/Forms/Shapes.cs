﻿using KursovaV2.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KursovaV2.Forms
{
    public abstract class Shapes : IShapes
    {
        public Point Position { get; private set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public double Base { get; set; }

        // За площа
        public abstract double CalculateArea();

        public Point MyProperty { get; private set; }

        // За Изрисуването 
        public abstract void Draw(Graphics g);

        public Color ShapesColor { get; set; }

        //public delegate void ShapeChangedEventHandler(string message);
    }
}
